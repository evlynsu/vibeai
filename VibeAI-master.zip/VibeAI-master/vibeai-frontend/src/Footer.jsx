
function Footer() {
    return(
        <footer>
            <p>&copy; {new Date().getFullYear()} VibeAI Groop 11</p>
        </footer>
    );
}

export default Footer