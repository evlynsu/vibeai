For a demo,

1. Download the repo to your local computer.
2. Change directory to the 'vibeai-frontend' folder
3. run 'npm i' or 'npm install'
4. Change directory back to the root repository ('/VibeAI')
5. run 'npm start'
6. Open webbrowser to the local host
